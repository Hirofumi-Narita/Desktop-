﻿// 2012/08/04
// narita-h

using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Text;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Interop;
using System.Windows.Input;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Runtime.InteropServices;
using System.Diagnostics;
using Microsoft.Win32;
using System.Threading.Tasks;
using System.Windows.Threading;


namespace Desktop_pp
{
    /*-----------------------------------------------------------------------------------------
     * 「主な処理」
     *      ○コンストラクタ
     *          ・設定ファイル読み込み
     *          ・サイドメニューに表示するアイコン作成
     *          
     *      ○メインウィンドウ
     *          ・マウスフック
     *          ・キーボードフック
     *          ・アプリケーション終了イベント
     *      
     *      ○表示ウィンドウ
     *          ・現在のデスクトップの状態を表示
     *              ↑これの変更とかをする処理（追加、削除、変更など）
     *          ・表示ウィンドウのクリックイベント
     *      
     *      ○オプションウィンドウ
     *          ・設定の変更をするウィンドウ初期設定
     *          ・設定を変更するのに必要なメソッド
     *          
     *      ○サイドバー
     *          ・クリックイベント
     *          ・レジストリ変更
     *          ・プロセスを隠したりする
     *          ・デスクトップのアイコンを並び替える
     *          
     *      ○APIのclass
     *          ・キーフック
     *          ・マウスフック
     *          ・デスクトップのアイコン
     *          ・explorer再起動
     -----------------------------------------------------------------------------------------*/

    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// mainのウィンドウ
    /// </summary>
    public partial class MainWindow : Window
    {
        /*****************************************************************************************
         *****************************************************************************************
         *****************************************************************************************
         *****                                                                               *****
         *****                          変数宣言, DllImport                                  *****
         *****                                                                               *****
         *****************************************************************************************
         *****************************************************************************************
         *****************************************************************************************/
        
        // インスタンス作成
        System.Windows.Forms.NotifyIcon notifyIcon = new System.Windows.Forms.NotifyIcon();

        // 現在のフォルダ番号を保持
        private int num = 0;

        // ディスプレイの高さと幅を取得
        private double maxX = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Width;
        private double maxY = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Height;
        
        // レジストリのkeyの定数
        private static string wallkey;
        private const string deskpath = @"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders";
        private const string wallkeypath = @"HKEY_CURRENT_USER\Software\Microsoft\Internet Explorer\Desktop\General";
        private const string wallpath = @"HKEY_CURRENT_USER\Control Panel\Desktop";

        // 解放するapi？
        [DllImport("gdi32.dll")]
        private static extern bool DeleteObject(IntPtr hObject);

        // 壁紙関連のdllを読み込む
        [DllImport("user32.dll")]
        private static extern bool SystemParametersInfo(uint uiAction, uint uiParam, string pvParam, uint fWinIni);

        // 外部プロセスのウィンドウを隠したり，表示させたりする
        [DllImport("user32.dll")]
        static extern bool SetWindowPos(IntPtr hWnd, uint hWndInsertAfter, int x, int y, int cx, int cy, uint flags);

        // プロセスを切るapi
        [DllImport("kernel32.dll")]
        public static extern int TerminateProcess(IntPtr hProcess, UInt32 uExitCode);

        // 現在のデスクトップを表すラジオボタン
        private static List<RadioButton> radlist = new List<RadioButton>();
        // ボタンの数をカウント
        int counter = 1;

        // 現在のデスクトップのプロセスを保存する
        private static List<List<IntPtr>> myProcess = new List<List<IntPtr>>();

        // 表示画面をドラッグされているかどうかのフラグ
        private bool drag = false;

        // 表示画面を移動するときに始点となる座標を保存する変数
        private System.Windows.Point point;

        // マウスのAPI用のデリゲード
        WinHookAPI.HookProcedureDelegate mouse_proc, key_proc;

        // オプションのウィンドウ
        optionWindow opwindow = new optionWindow();

        // デスクトップの移動をするときに使う,右と左の関数
        const int RIGHT = -1, LEFT = 1;

        //const uint SWP_NOMOVE = 0x0002;     //サイズだけを変える
        //const uint SWP_NOSIZE = 0x0001;     //サイズを変えない
        //const uint SWP_NOACTIVATE = 0x10;   //アクティブにしない
        //const uint SWP_HIDEWINDOW = 0x80;   //非表示に
        //const uint SWP_SHOWWINDOW = 0x40;   //再表示に
        const uint HWND_TOP = 0;            //Zオーダーのトップに置く
        const uint WSP_HIDE = (0x0002 | 0x0001 | 0x10 | 0x80);  // 隠すときの上の組み合わせ
        const uint WSP_SHOW = (0x0002 | 0x0001 | 0x10 | 0x40);　// 表示するときの上の組み合わせ

        // ラジオボタンでデスクトップを移動するときに押したボタンを保持しておく変数
        private RadioButton sedrad;
        // デスクトップの切り替えが終了したことを示すフラグ
        bool deskchange_flg = false, dic_flg = false, schide_flg = false;

        // 表示ウィンドウが表示されているかどうか
        bool priwin_vflg = true;

        // ctrlが押されたかどうかのフラグ
        bool ctrl_flag = false;

        // デスクトップの移動後の処理を行うタイマー（応急処置）
        System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
        
        /*****************************************************************************************
         *****************************************************************************************
         *****************************************************************************************
         *****                                                                               *****
         *****                              コンストラクタ                                   *****
         *****                                                                               *****
         *****************************************************************************************
         *****************************************************************************************
         *****************************************************************************************/
       
        //---------------------------------------------------------------------

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public MainWindow()
        {
            //二重起動をチェックする
            if (Process.GetProcessesByName(Process.GetCurrentProcess().ProcessName).Length > 1)
            {
                MessageBox.Show("すでに起動しています。");
                Application.Current.Shutdown();
            }

            // ウィンドウデザイナー読み込み
            InitializeComponent();
            // 設定を読み込む
            SetData.LoadXmlFile();

            // ラジオボタンを一つ追加（初期デスクトップ分）
            radlist.Add(radbutton0);
            // プロセスを一つ追加（初期デスクトップ分）
            myProcess.Add(new List<IntPtr>());

            // ウィンドウ背景を透明にすることを許可する
            this.AllowsTransparency = true;
            // ウィンドウの大きさをディスプレイのサイズに合わせる
            this.Height = maxY;
            this.Width = maxX;

            // サイドバーのクリックイベントを追加
            rightbutton.Click += (sender, e) => DesktopMove(num - 1, num + 1, RIGHT);
            leftbutton.Click += (sender, e) => DesktopMove(num - 1, num + 1, LEFT);
            // サイドバーを自動的に隠す
            rightbutton.MouseLeave += (sender, e) => rightbutton.Visibility = Visibility.Collapsed;
            leftbutton.MouseLeave += (sender, e) => leftbutton.Visibility = Visibility.Collapsed;
            // サイドバーの色変更
            leftbutton.Background = SetData.DATA.mcolor;
            // サイドバーの大きさ変更
            sizeChange(SetData.DATA.sideh, SetData.DATA.sidec);
            // サイドバーの透明度を変更
            rightbutton.Opacity = leftbutton.Opacity = SetData.DATA.sideo / 100;
            // サイドバーの表示をするかどうか
            if (!SetData.DATA.privisi) {
                rightbutton.Visibility = leftbutton.Visibility = Visibility.Collapsed;
            }

            // パソコンosのversion取得
            Version OSver = Environment.OSVersion.Version;
            // windows7だったら
            if ((OSver.Major == 6 && OSver.Minor >= 1) || OSver.Major > 6) {
                wallkey = "WallpaperSource";
            }
            // それ以外だったら
            else {
                wallkey = "Wallpaper";
            }

            //現在アクティプなプロセスに関連付ける
            using (Process process = Process.GetCurrentProcess())
            {
                //関連付けられたプロセスのメインモジュールを取得
                using (ProcessModule module = process.MainModule)
                {
                    // keyboardhook
                    KeyboardHookInfo.hHook = WinHookAPI.SetWindowsHookEx(
                    KeyboardHookInfo.WM_KEYBOARD_LL,
                    key_proc = new WinHookAPI.HookProcedureDelegate(KeyBoardHookProc),
                    WinHookAPI.GetModuleHandle(module.ModuleName), 0);

                    // mousehook
                    MouseHookInfo.hHook = WinHookAPI.SetWindowsHookEx(
                    MouseHookInfo.WH_MOUSE_LL,
                    mouse_proc = new WinHookAPI.HookProcedureDelegate(MouseHookProc),
                    WinHookAPI.GetModuleHandle(module.ModuleName), 0);
                }
            }

            // NotifyIcon の作成をする
            makeItem();

            // オプションウィンドウの初期化
            opwindow.set();
            
            // オプションウィンドウを作る
            make_optionwindow();

            // ラジオボタンを現在あるデスクトップの数分作成して配置
            for (int i = 1; i < SetData.DATA.name.Count(); i++) {
                Addbutton();
                myProcess.Add(new List<IntPtr>());
            }

            // 表示画面の透明度変更
            ract.Opacity = SetData.DATA.prio / 100;
            // 表示画面のカラー変更
            print.Fill = SetData.DATA.pcolor;

            // 現在のデスクトップの場所を初期にする
            num = 0;
            // imageの大きさをディスプレイの大きさに合わせる
            image1.SetValue(Canvas.LeftProperty, 0.0);
            image2.SetValue(Canvas.LeftProperty, maxX);
            image3.SetValue(Canvas.LeftProperty, (-1) * maxX);

            timer.Tick += new EventHandler(timer_Tick);
            timer.Interval = 10;

            // デバッグ用
            //this.Topmost = false; //topmostをfalse
            //this.MouseLeftButtonDown += (sender, e) => this.DragMove(); //window移動できる
        }

        //---------------------------------------------------------------------
        /// <summary>
        ///　notifyIcon作成 
        /// </summary>
        private void makeItem()
        {
            // タスクトレイアイコンを初期化する
            notifyIcon.Text = "DesktopChange\nメニューの表示";
            notifyIcon.Icon = Properties.Resources.icon完成fx;
            notifyIcon.Visible = true;

            // アイコンにコンテキストメニュー「オプション」を追加する
            System.Windows.Forms.ToolStripMenuItem setItem = new System.Windows.Forms.ToolStripMenuItem();
            setItem.Text = "オプション";
            setItem.Click += (sender, e) =>
            {
                // 現在のデスクトップの背景を保存する
                SetData.DATA.image[SetData.DATA.number] = Registry.GetValue(wallkeypath, wallkey, "default") as string;
                // サイドバーを表示する
                rightbutton.Visibility = Visibility.Visible;
                leftbutton.Visibility = Visibility.Visible;
                // オプション表示
                opwindow.ShowDialog();
                // サイドバーを隠す
                rightbutton.Visibility = Visibility.Collapsed;
                leftbutton.Visibility = Visibility.Collapsed;
            };

            // アイコンにコンテキストメニュー「終了」を追加する
            System.Windows.Forms.ToolStripMenuItem exitItem = new System.Windows.Forms.ToolStripMenuItem();
            exitItem.Text = "終了";
            exitItem.Click += (sender, e) => Window_Closing(null, null);

            // 作成したmenuを追加する
            System.Windows.Forms.ContextMenuStrip menuStrip = new System.Windows.Forms.ContextMenuStrip();
            menuStrip.Items.Add(setItem);
            menuStrip.Items.Add(exitItem);
            notifyIcon.ContextMenuStrip = menuStrip;
        }

        /*****************************************************************************************
         *****************************************************************************************
         *****************************************************************************************
         *****                                                                               *****
         *****                              メインウィンドウ                                 *****
         *****                                                                               *****
         *****************************************************************************************
         *****************************************************************************************
         *****************************************************************************************/

        //---------------------------------------------------------------------
        /// <summary>
        /// マウスフックプロシージャの実装を行う
        /// </summary>
        /// <param name="nCode"></param>
        /// <param name="wParam"></param>
        /// <param name="lParam"></param>
        /// <returns></returns>
        private IntPtr MouseHookProc(int nCode, IntPtr wParam, IntPtr lParam)
        {
            //0以上
            if (nCode >= 0)
            {
                // コールバックからのデータを整理する(削除する)
                MouseHookInfo.MouseHookStruct MyMouseHookStruct = (MouseHookInfo.MouseHookStruct)Marshal.PtrToStructure(lParam, typeof(MouseHookInfo.MouseHookStruct));

                // マウスの座標を取得する
                int x = System.Windows.Forms.Cursor.Position.X;
                int y = System.Windows.Forms.Cursor.Position.Y;

                // マウスのなんなかのボタンが押されたとき
                if ((int)wParam == MouseHookInfo.WM_MBUTTONDOWN)
                {
                    // 表示ウィンドウを表示したり，隠したりする
                    if (pri.Visibility == Visibility.Collapsed)
                    {
                        priwin_vflg = true;
                        pri.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        priwin_vflg = false;
                        pri.Visibility = Visibility.Collapsed;
                    }
                }
                
                //　マウスポインタが動いているとき
                if ((int)wParam == MouseHookInfo.WM_MOUSEMOVE)
                {
                    // マウスポインタが X 座標 5 以上, Y 座標 1/4 以上のとき
                    if (x < 2 && SetData.DATA.privisi)
                    {
                        // ボタンを表示
                        leftbutton.Visibility = Visibility.Visible;
                    }

                    // マウスポインタが 最大 X 座標 5 以上, Y 座標 3/4 以下のとき
                    if (x > maxX - 2 && SetData.DATA.privisi)
                    {
                        // ボタンを表示
                        rightbutton.Visibility = Visibility.Visible;
                    }

                    // 表示ウィドウがドラックされているとき
                    if (drag == true)
                    {
                        // 表示ウィンドウを移動
                        Canvas.SetLeft(pri, x - point.X);
                        Canvas.SetTop(pri, y - point.Y);
                        // ウィンドウにマウスポインタを表示
                        print.CaptureMouse();
                    }
                }
            }
            //マウスを返す
            return WinHookAPI.CallNextHookEx(MouseHookInfo.hHook, nCode, wParam, lParam);
        }

        //---------------------------------------------------------------------

        /// <summary>
        /// キーボードフックプロシージャの実装を行う
        /// </summary>
        /// <param name="nCode"></param>
        /// <param name="wParam"></param>
        /// <param name="lParam"></param>
        /// <returns></returns>
        protected IntPtr KeyBoardHookProc(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0)
            {
                // コールバックからのデータを整理する(削除する)
                KeyboardHookInfo.KeyboardHookStruct KeyboardInfo = (KeyboardHookInfo.KeyboardHookStruct)Marshal.PtrToStructure(lParam, typeof(KeyboardHookInfo.KeyboardHookStruct));
                
                // キーボードの入力があったとき
                if (KeyboardHookInfo.WM_KEYDOWN == (int)wParam)
                {
                    // ctrlならフラグを立てる
                    if (KeyboardInfo.VKCode == KeyboardHookInfo.VK_LCONTROL || 
                        KeyboardInfo.VKCode == KeyboardHookInfo.VK_RCONTROL ||
                        KeyboardInfo.VKCode == KeyboardHookInfo.VK_CONTROL 
                        )
                    {
                        ctrl_flag = true;
                    }
                    // ctrl押しながら→を押したとき
                    else if (KeyboardInfo.VKCode == KeyboardHookInfo.VK_RIGHT && ctrl_flag)
                    {
                        // デスクトップ切り替え
                        DesktopMove(num - 1, num + 1, RIGHT);
                        ctrl_flag = false;
                    }
                    // ctrl押しながら←を押したとき
                    else if (KeyboardInfo.VKCode == KeyboardHookInfo.VK_LEFT && ctrl_flag)
                    {
                        // デスクトップ切り替え
                        DesktopMove(num - 1, num + 1, LEFT);
                        ctrl_flag = false;
                    }
                    // それ以外を押したとき
                    else
                    {
                        ctrl_flag = false;
                    }
                }
                // キーボードが離されたら
                else if (KeyboardHookInfo.WM_KEYUP == (int)wParam)
                {
                    // それがctrlキーだったらflagをきる
                    if (KeyboardInfo.VKCode == KeyboardHookInfo.VK_LCONTROL ||
                        KeyboardInfo.VKCode == KeyboardHookInfo.VK_RCONTROL ||
                        KeyboardInfo.VKCode == KeyboardHookInfo.VK_CONTROL
                        )
                    {
                        ctrl_flag = false;
                    }
                }
            }

            //押されたキーの値を返す
            return WinHookAPI.CallNextHookEx(KeyboardHookInfo.hHook, nCode, wParam, lParam);
        }

        //---------------------------------------------------------------------
        /// <summary>
        /// ウィンドウの終了イベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // 「Alt」 + 「F4」とかで消されそうになったとき 
            if (sender != null || e != null)
            {
                // イベントをキャンセルしてreturn
                e.Cancel = true;
                return;
            }
            // タスクトレイアイコン解放
            notifyIcon.Dispose();
            // 元のデスクトップに戻す
            SetData.DATA.number = 0;
            num = 0;
            // デスクトップを移動する
            ChangeDesktop();
            // デスクトップ移動後の処理
            DeskMoveEnd();

            // 設定を保存
            SetData.SaveXmlFile();
            // プロセスを全て表示
            ShowAll_process();
            // アプリケーションを終了
            Application.Current.Shutdown();
        }

        //---------------------------------------------------------------------
        /// <summary>
        /// しょうがないからタイマーでデスクトップの切り替え終了後の処理を行う
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void timer_Tick(object sender, EventArgs e)
        {
            if (schide_flg)
            {
                // アニメーションに使用したimageを隠す
                scroll.Visibility = Visibility.Collapsed;
                // 背景の壁紙を変更
                ChangeImage();
                // フラグ切る
                schide_flg = false;
                // タイマー止める
                timer.Stop();
            }
        }

        /*****************************************************************************************
         *****************************************************************************************
         *****************************************************************************************
         *****                                                                               *****
         *****                                表示ウィンドウ                                 *****
         *****                                                                               *****
         *****************************************************************************************
         *****************************************************************************************
         *****************************************************************************************/

        //---------------------------------------------------------------------
        /// <summary>
        /// ラジオボタンを１つ追加する
        /// </summary>
        public void Addbutton()
        {
            // デスクトップの数とボタンを数が同じだったら作らない
            if (SetData.DATA.name.Count() == counter) return;

            // ラジオボタンの数をインクリメント
            counter++;

            // ラジオボタンを作成
            RadioButton rad = new RadioButton();
            // 高さを設定
            rad.Height = 15;
            // 位置を設定
            rad.SetValue(Canvas.TopProperty, 50.0);
            rad.SetValue(Canvas.LeftProperty, 20.0 * counter);
            rad.SetValue(Panel.ZIndexProperty, 10);

            // イベントの追加
            rad.Checked += radbutton_Checked;
            rad.MouseEnter += radbutton_MouseEnter;
            rad.MouseLeave += radbutton_MouseLeave;

            // ラジオボタン追加
            pri.Children.Add(rad);
            
            // ラジオボタンを管理するリストに追加
            radlist.Add(rad);

            // プロセスのリストを追加
            myProcess.Add(new List<IntPtr>());
            // デスクトップのアイコン座標リスト追加
            SetData.DATA.ipoint.Add(new List<System.Drawing.Point>());
            SetData.DATA.iname.Add(new List<string>());
        }

        //---------------------------------------------------------------------
        /// <summary>
        /// ラジオボタンを１つ削除する
        /// </summary>
        public void Removebutton()
        {
            // 初期デスクトップが選択されている場合
            if (opwindow.foldlist.SelectedIndex == 0)
            {
                MessageBox.Show("初期デスクトップは，\n削除することはできません。", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            // 現在のデスクトップが選択されている場合
            else if (SetData.DATA.number == opwindow.foldlist.SelectedIndex)
            {
                MessageBox.Show("現在選択されているデスクトップは，\n削除することはできません。", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            else if (opwindow.foldlist.SelectedIndex < 0) return;

            // デクリメント
            counter--;

            // イベントの削除
            radlist[counter].Checked -= radbutton_Checked;
            radlist[counter].MouseEnter -= radbutton_MouseEnter;
            radlist[counter].MouseLeave -= radbutton_MouseLeave;
            // デスクトップのアイコンの座標データの削除
            SetData.DATA.ipoint.RemoveAt(opwindow.foldlist.SelectedIndex);
            // プロセスのデータ削除
            myProcess.RemoveAt(opwindow.foldlist.SelectedIndex);

            // ラジオボタンをcanvasから削除
            pri.Children.Remove(radlist[counter]);
            // ラジオボタンをリストから削除
            radlist.RemoveAt(counter);

            // パスの作成
            string pass = @"C:\Desktop++;\" + SetData.DATA.name[opwindow.foldlist.SelectedIndex];

            // そのフォルダを削除
            SetData.DATA.name.RemoveAt(opwindow.foldlist.SelectedIndex);
            SetData.DATA.image.RemoveAt(opwindow.foldlist.SelectedIndex);
            SetData.DATA.scrimg.RemoveAt(opwindow.foldlist.SelectedIndex);
            System.IO.Directory.Delete(pass, true);

            // リストボックスから削除
            opwindow.foldlist.Items.RemoveAt(opwindow.foldlist.SelectedIndex);

            // テキストボックスに選択したフォルダの名前を代入する
            opwindow.nametext.Text = SetData.DATA.name[0];
            try
            {
                // テキストボックスに選択した壁紙のパスを代入
                opwindow.image1.Source = new BitmapImage(new Uri(SetData.DATA.image[0]));
                opwindow.image1.Stretch = Stretch.Uniform;
            }
            catch
            {
                opwindow.image1.Source = null;
            }
        }

        //---------------------------------------------------------------------
        /// <summary>
        /// 表示ウィンドウを右クリックしたら，オプションを表示する
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItem_option(object sender, RoutedEventArgs e)
        {
            // 現在のデスクトップの背景を保存する
            SetData.DATA.image[SetData.DATA.number] = Registry.GetValue(wallkeypath, wallkey, "default") as string;
            // サイドバーを表示する
            rightbutton.Visibility = Visibility.Visible;
            leftbutton.Visibility = Visibility.Visible;
            // オプション表示
            opwindow.ShowDialog();
            // サイドバーを隠す
            rightbutton.Visibility = Visibility.Collapsed;
            leftbutton.Visibility = Visibility.Collapsed;
        }

        //---------------------------------------------------------------------
        /// <summary>
        /// 表示ウィンドウが掴まれたらドラッグ開始
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void print_ButtonDown(object sender, MouseButtonEventArgs e)
        {
            // フラグを立てる
            drag = true;
            // 掴んだ場所を取得
            point = e.GetPosition(pri);
            // マウスポインタを表示
            print.CaptureMouse();
        }

        //---------------------------------------------------------------------
        /// <summary>
        /// 表示ウィンドウが離されたらドラッグ終了
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void print_ButtonUp(object sender, MouseButtonEventArgs e)
        {
            // フラグをきる
            drag = false;
            // マウスキャプチャーを解放
            Mouse.Capture(null);
        }

        //---------------------------------------------------------------------
        /// <summary>
        /// ラジオボタンをチェックしたらそのデスクトップに移動する
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void radbutton_Checked(object sender, RoutedEventArgs e)
        {
            // sender をラジオボタンに変換
            sedrad = (RadioButton)sender;

            // ラジオボタンの場所を検索
            int rad = radlist.FindIndex(radcheck);

            // 左の方が近かったら左方向に移動
            if (rad > -1 && rad < SetData.DATA.number) DesktopMove(rad, num, LEFT);
            // 右の方が近かったら右方向に移動
            else if (rad > -1 && rad > SetData.DATA.number) DesktopMove(num, rad, RIGHT);
        }

        //---------------------------------------------------------------------
        /// <summary>
        /// radlistのfindIndexに使用するかんすう
        /// </summary>
        /// <param name="radtmp"></param>
        /// <returns></returns>
        private bool radcheck(RadioButton radtmp)
        {
            // sender のラジオボタンと同じだったら true
            return radtmp == sedrad;
        }

        //---------------------------------------------------------------------
        /// <summary>
        /// ラジオボタンの領域にマウスが入ったらそのデスクトップの名前を表示する
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void radbutton_MouseEnter(object sender, MouseEventArgs e)
        {
            // senderをラジオボタンに変換
            sedrad = (RadioButton)sender;
            // 何番目のラジオボタンなのか検索
            int rad = radlist.FindIndex(radcheck);

            // そのラジオボタンがあったら表示名を変更
            if (rad != -1)  nametxt.Content = SetData.DATA.name[rad];
        }

        //---------------------------------------------------------------------
        /// <summary>
        /// ラジオボタンの領域からマウスが離れたら元の名前を表示する
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void radbutton_MouseLeave(object sender, MouseEventArgs e)
        {
            // 表示名を変更
            nametxt.Content = SetData.DATA.name[num];
        }

        /*****************************************************************************************
         *****************************************************************************************
         *****************************************************************************************
         *****                                                                               *****
         *****                           オプションウィンドウ                                *****
         *****                                                                               *****
         *****************************************************************************************
         *****************************************************************************************
         *****************************************************************************************/
        //---------------------------------------------------------------------
        /// <summary>
        /// サイドバーの大きさと位置の変更のメソッド
        /// </summary>
        private void sizeChange(double sizebar, double centbar)
        {
            // valueの値(doble型)をHeightの値(GridLength型)に変換するクラス
            GridLengthConverter gridconv = new GridLengthConverter();

            // 基準値の宣言
            const double size = 258.0, cent = 516.0;
            double si = size - (sizebar / 100) * size;
            double ce = (centbar / 100) * cent, uh, dh;
            
            // 変更値を基準値に足す
            uh = si + ce;
            dh = si + ce * -1;
            // 負の値は 0 にする
            if (uh < 0) uh = 0;
            if (dh < 0) dh = 0;
            
            // 変換して代入
            uHeight.Height = (GridLength)gridconv.ConvertFrom(uh);
            dHeight.Height = (GridLength)gridconv.ConvertFrom(dh);
        }

        //---------------------------------------------------------------------
        /// <summary>
        /// オプションのウィンドウを作成する
        /// また，そのウィンドウのコントロールのイベントなどの作成
        /// </summary>
        private void make_optionwindow()
        {
            // デスクトップの追加を押したときのイベントの追加
            opwindow.addbutton.Click += (sender, e) => Addbutton();

            // デスクトップの削除を押したときのイベントの追加
            opwindow.deletebutton.Click += (sender, e) => Removebutton();

            // サイドバーの大きさを変更するイベント追加
            opwindow.sizebar.ValueChanged += (sender, e) => sizeChange(opwindow.sizebar.Value, opwindow.centbar.Value);

            // サイドバーの位置を変更するイベント追加
            opwindow.centbar.ValueChanged += (sender, e) => sizeChange(opwindow.sizebar.Value, opwindow.centbar.Value);

            // サイドバーの透明度の変更イベントの追加
            opwindow.opacbar.ValueChanged += (sender, e) => rightbutton.Opacity = leftbutton.Opacity = opwindow.opacbar.Value / 100;

            // 表示ウィンドウの透明度の変更イベントの追加
            opwindow.opacpri.ValueChanged += (sender, e) => ract.Opacity = opwindow.opacpri.Value / 100;

            // サイド場ー表示方法変更イベントの追加
            opwindow.topcheck.Click += (sender, e) => this.Topmost = (bool)opwindow.topcheck.IsChecked;

            // サイドバーの背景色を変更する
            opwindow.corbuuton1.Click += (sender, e) =>
            {

                #region 処理

                // 色を変更するためにカラーダイアログボックスを作成
                System.Windows.Forms.ColorDialog cd = new System.Windows.Forms.ColorDialog();

                // カスタムカラーが作られていたら反映させる 
                if(SetData.DATA.setcolor != null) cd.CustomColors = SetData.DATA.setcolor;

                // 色が選択されたら
                if (cd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    // window.from型の色をwindows.media型に変換する
                    Color color = Color.FromArgb(cd.Color.A, cd.Color.R, cd.Color.G, cd.Color.B);
                    SolidColorBrush brush = new SolidColorBrush();
                    // 変換した色を代入する
                    brush.Color = color;
                    // 色を変更する
                    leftbutton.Background = brush;
                    opwindow.mcolorabel.Background = brush;
                }

                // カスタムカラーを保存する
                SetData.DATA.setcolor = cd.CustomColors;

                #endregion
            };

            // 表示ウィンドウの背景色を変更する
            opwindow.corbuuton2.Click += (sender, e) =>
            {
                #region 処理

                // 色を変更するためにカラーダイアログボックスを作成
                System.Windows.Forms.ColorDialog cd = new System.Windows.Forms.ColorDialog();

                // カスタムカラーが作られていたら反映させる
                if (SetData.DATA.setcolor != null) cd.CustomColors = SetData.DATA.setcolor;

                // 色が選択されたら
                if (cd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    // window.from型の色をwindows.media型に変換する
                    Color color = Color.FromArgb(cd.Color.A, cd.Color.R, cd.Color.G, cd.Color.B);
                    SolidColorBrush brush = new SolidColorBrush();
                    // 変換した色を代入する
                    brush.Color = color;
                    // 色を変更する
                    print.Fill = brush;
                    opwindow.pcolorabel.Background = brush;
                }

                // カスタムカラーを保存する
                SetData.DATA.setcolor = cd.CustomColors;
               
                #endregion
            };

            // 設定をリセットする
            opwindow.reset.Click += (sender, e) =>
            {
                // メッセージを表示する
                MessageBoxResult result = MessageBox.Show("設定を初期化しますか？\n\n※データは全て消えてしまいます。", "確認",
                    MessageBoxButton.OKCancel,MessageBoxImage.Warning);

                // OKが押されたら
                if (result == MessageBoxResult.OK)
                {
                    // メッセージを表示する
                    MessageBoxResult result2 = MessageBox.Show("※アプリケーションを一度終了する必要があります。\n\nよろしいですか？", "確認",
                        MessageBoxButton.OKCancel, MessageBoxImage.Warning);
                    
                    // OKが押されたら
                    if (result2 == MessageBoxResult.OK)
                    {
                        // 設定ファイルを削除する
                        System.IO.Directory.Delete(SetData.setpath, true);
                        // タスクトレイアイコン解放
                        notifyIcon.Dispose();
                        // 元のデスクトップに戻す
                        SetData.DATA.number = 0;
                        num = 0;
                        // デスクトップを変更する
                        ChangeDesktop();
                        // デスクトップ変更後の処理をする
                        DeskMoveEnd();
                        // プロセスを全て表示
                        ShowAll_process();
                        // アプリケーションを終了
                        Application.Current.Shutdown();
                    }
                }
            };

        }

        /*****************************************************************************************
         *****************************************************************************************
         *****************************************************************************************
         *****                                                                               *****
         *****                                  サイドバー                                   *****
         *****                                                                               *****
         *****************************************************************************************
         *****************************************************************************************
         *****************************************************************************************/


        //*********************************************************************************
        //--------------------------- レジストリ関連のメソッド ------------------------------
        //*********************************************************************************
        //---------------------------------------------------------------------
        /// <summary>
        /// レジストリを読み込み、現在のデスクトップのパスを返す
        /// </summary>
        /// <returns></returns>
        public void ChangeDesktop()
        {
            // フォルダのパス
            string path = @"C:\Desktop++;\" + SetData.DATA.name[SetData.DATA.number];
            // 初期デスクトップの場合は，defalutのデスクトップのパスをあたえる
            if (SetData.DATA.number == 0)   path = SetData.DATA.defdesk;
            // レジストリに書き込み，デスクトップを変更する
            Registry.SetValue(deskpath, "Desktop", path, RegistryValueKind.ExpandString);
        }

        //---------------------------------------------------------------------
        /// <summary>
        /// apiとレジストリを使い，背景を変更する
        /// </summary>
        /// <returns></returns>
        public void ChangeImage()
        {
            try
            {
                // 定数
                const uint SPI_SETDESKWALLPAPER = 20;
                //const uint SPIF_UPDATEINIFILE = 1;
                //const uint SPIF_SENDWININICHANGE = 2;

                //壁紙を変更
                SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, SetData.DATA.image[SetData.DATA.number], 0);
                // レジストリ書き込み 
                Registry.SetValue(wallpath, "Wallpaper", SetData.DATA.image[SetData.DATA.number]);
                Registry.SetValue(wallkeypath, wallkey, SetData.DATA.image[SetData.DATA.number]);
            }
            catch (Exception) { }
        }

        //*********************************************************************************
        //----------------------------- 移動関連のメソッド ------------------------------
        //*********************************************************************************
        //---------------------------------------------------------------------
        /// <summary>
        /// デスクトップをいどうする
        /// </summary>
        /// <param name="Lnum"> 左側のデスクトップの値 </param>
        /// <param name="Rnum"> 右側のデスクトップの値</param>
        /// <param name="MODE"> RIGHT か LEFT か </param>
        private void DesktopMove(int Lnum, int Rnum, int MODE)
        {
            // 移動中は押せないようにする
            if (deskchange_flg) return;

            // デスクトップ移動開始
            deskchange_flg = true;

            // サイドバーを隠す
            leftbutton.Visibility = rightbutton.Visibility = Visibility.Collapsed;

            // 最大デスクトップ数より大きくなったら 0 にする
            if (Lnum < 0) { Lnum = SetData.DATA.name.Count() - 1; }
            // マイナスになったら，最大デスクトップ数にする
            if (Rnum >= SetData.DATA.name.Count()) { Rnum = 0; }

            // 現在のデスクトップの背景を保存する
            SetData.DATA.image[SetData.DATA.number] = Registry.GetValue(wallkeypath, wallkey, "default") as string;
            // スクリーンショットをとって表示する
            PrintScreen(Lnum, Rnum);
            
            // 起動中のアプリケーションを隠す
            Hide_process();

            // デスクトップのアイコンの場所を取得
            SetData.DATA.ipoint[num].Clear();
            SetData.DATA.ipoint[num] = WinProcessAPI.GetIconPosition();
            SetData.DATA.iname[num].Clear();
            SetData.DATA.iname[num] = WinProcessAPI.GetIconName();

            // デスクトップ移動
            if (MODE == RIGHT) SetData.DATA.number = num = Rnum;
            if (MODE == LEFT) SetData.DATA.number = num = Lnum;
            
            // デスクトップを変更する（タスク処理）
            var task1 = Task.Factory.StartNew(ChangeDesktop);
            
            // 現在のデスクトップの情報更新
            radlist[SetData.DATA.number].IsChecked = true;
            nametxt.Content = SetData.DATA.name[SetData.DATA.number];

            // タスクが終了するまで待つ
            Task.WaitAll( task1 );

            // アニメーション開始
            if (SetData.DATA.aniflg)  scroll.BeginAnimation(Canvas.LeftProperty, ScrollAnimation(MODE));
            // アニメーションを使わない設定のとき
            else
            {
                // 移動先のデスクトップのスクリーンショットを表示
                image1.Source = SetData.DATA.scrimg[num];
                // デスクトップを変更後の処理
                DeskMoveEnd();
            }
        }

        //---------------------------------------------------------------------
        /// <summary>
        /// デスクトップを移動した後の処理
        /// </summary>
        private void DeskMoveEnd()
        {
            // タイマー起動
            timer.Start();

            // クリップボードのデータを保存するためにクリップボードのデータを
            // 一時的に保存し，それぞれの種類にあった方法でクリップボードにセットする
            if (Clipboard.ContainsAudio())
            {
                // クリップボードを一時的にに保存
                var temp = Clipboard.GetAudioStream();

                // explorer再起動
                explorer_kill();

                // クリップボードにセット
                Clipboard.SetAudio(temp);
            }
            else if (Clipboard.ContainsFileDropList())
            {
                // クリップボードを一時的にに保存
                var temp = Clipboard.GetFileDropList();

                // explorer再起動
                explorer_kill();

                // クリップボードにセット
                Clipboard.SetFileDropList(temp);
            }
            else if (Clipboard.ContainsImage())
            {
                // クリップボードを一時的にに保存
                var temp = Clipboard.GetImage();

                // explorer再起動
                explorer_kill();

                // クリップボードにセット
                Clipboard.SetImage(temp);
            }
            else if (Clipboard.ContainsText())
            {
                // クリップボードを一時的にに保存
                var temp = Clipboard.GetText();

                // explorer再起動
                explorer_kill();

                // クリップボードにセット
                Clipboard.SetText(temp);
            }
            else
            {
                // explorer再起動
                explorer_kill();
            }
        }

        //---------------------------------------------------------------------
        /// <summary>
        /// 画面をスクロールするアニメーション
        /// </summary>
        /// <param name="MODE"> LEFT　か RIGHT か </param>
        /// <returns> 作成したアニメーション </returns>
        private DoubleAnimation ScrollAnimation(int MODE)
        {
            DoubleAnimation animation = new DoubleAnimation
            {
                // 0から
                From = 0,
                // ディスプレイの横幅まで
                To = (maxX ) * MODE,
                // 0.5秒間
                Duration = TimeSpan.FromMilliseconds(400)
            };
            // アニメーションが終わったときのイベント
            animation.Completed += (sender, e) => DeskMoveEnd();

            return animation;
        }

        //---------------------------------------------------------------------
        /// <summary>
        /// 画面をスクロールするためにスクリーンショットを取って
        /// image に表示させる
        /// </summary>
        /// <param name="Lnum"> 左側のデスクトップの値 </param>
        /// <param name="Rnum"> 右側のデスクトップの値 </param>
        public void PrintScreen(int Lnum, int Rnum)
        {
            // 位置を元に戻す
            scroll.SetValue(Canvas.LeftProperty, 0.0);

            // 画面サイズのBitmapの作成
            System.Drawing.Bitmap bmp = new System.Drawing.Bitmap(System.Windows.Forms.Screen.PrimaryScreen.Bounds.Width, System.Windows.Forms.Screen.PrimaryScreen.Bounds.Height);
            //Graphicsの作成
            System.Drawing.Graphics g = System.Drawing.Graphics.FromImage(bmp);
            // 画面全体をコピーする
            g.CopyFromScreen(new System.Drawing.Point(0, 0), new System.Drawing.Point(0, 0), bmp.Size);
            // bmpの構造体のコピー
            IntPtr imagePtr = bmp.GetHbitmap();
            // Graphics 解放
            g.Dispose();
            // bitomap解放
            bmp.Dispose();

            // 表示
            image1.Source = image2.Source = image3.Source = Imaging.CreateBitmapSourceFromHBitmap(
                imagePtr, IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
            // bmpの構造体削除
            DeleteObject(imagePtr);

            // 取ったスクリーンショットを保存しておく
            SetData.DATA.scrimg[SetData.DATA.number] = image1.Source;

            // 画像があったらそれを表示する
            if (SetData.DATA.scrimg[Lnum] != null) image3.Source = SetData.DATA.scrimg[Lnum];
            if (SetData.DATA.scrimg[Rnum] != null) image2.Source = SetData.DATA.scrimg[Rnum];

            // imageを表示する
            scroll.Visibility = Visibility.Visible;

            // 表示ウィンドウを隠す
            pri.Visibility = Visibility.Collapsed;
        }
        
        //---------------------------------------------------------------------
        /// <summary>
        /// スレッドでexplorerが再起動したことを確認して，
        /// デスクトップのアイコンを並び替える
        /// </summary>public void DeskIconReset()
        public void DeskIconReset()
        {
            while (true)
            {
                // デスクトップ移動でアニメーションが終わったら
                if (dic_flg)
                {
                    // explorerが起動したことを確認
                    if (Process.GetProcessesByName("Explorer").Length > 0)
                    {
                        // フラグを切る
                        dic_flg = false;
                        // タスク処理
                        var task1 = Task.Factory.StartNew(() =>
                        {
                            // 少し待つ
                            System.Threading.Thread.Sleep(800);
                            // デスクトップのアイコンの場所を戻す
                            WinProcessAPI.SetIconPosition(SetData.DATA.ipoint[num], SetData.DATA.iname[num]);
                            // 背景の壁紙を変更
                            ChangeImage();
                        });

                        // 処理が終わるまでまつ
                        Task.WaitAll(task1);

                        // フラグを切る
                        deskchange_flg = false;

                        // デスクトップ移動後のすべての処理が終了フラグをたてる
                        schide_flg = true;

                        break;
                    }
                }
            }
        }

        //*********************************************************************************
        //--------------------------- プロセス関連のメソッド ------------------------------
        //*********************************************************************************


        /// <summary>
        /// explorer 再起動する。その後explorer再起動後の処理をする
        /// </summary>
        private void explorer_kill()
        {
            // explorerを再起動すると，クリップボードが消えるので
            // 一時的に保存しておく
            IDataObject data = Clipboard.GetDataObject();
            try
            {
                // explorerを取得し，全てkillする
                foreach (Process oProcess in Process.GetProcessesByName("Explorer"))
                {
                    TerminateProcess(oProcess.Handle, 1);
                    oProcess.WaitForExit();
                    oProcess.Close();
                }
            }
            catch (Exception) { }
            finally
            {
                // explorerを起動する
                Process p = Process.Start(Environment.GetEnvironmentVariable("windir")+"\\explorer.exe");
                // explorerが起動するまで待つ
                p.WaitForInputIdle();

                // 隠したアプリケーションを表示
                Show_process();

                // 表示ウィンドウを表示する
                if(priwin_vflg) pri.Visibility = Visibility.Visible;

                // クリップボードに保存しておいたデータをコピー
                Clipboard.SetDataObject(data);

                // アイコンを並び替える処理（タスク処理）をスタート
                var task = Task.Factory.StartNew(DeskIconReset);
                
                // デスクトップのアイコンを並べ替えるフラグを立てる
                dic_flg = true;
            }
        }

        //-------------------------------------------
        /// <summary>
        /// デスクトップを移動するときプロセスを隠す
        /// </summary>
        private void Hide_process()
        {
            // 設定が有効でないなら隠さない
            if (!SetData.DATA.workflg) return;

            // 今のデスクトップのプロセスを保存しておくリストを初期化
            myProcess[SetData.DATA.number].Clear();


            // apiでプロセスを取得し，その回数分まわす
            foreach (Process item in WinProcessAPI.GetAllWindows())
            {
                try
                {
                    // タスクマネージャーとnullとこのアプリのidは無視する
                    // デバッグ用にVisual c# も除外する
                    if (item.MainWindowHandle != IntPtr.Zero && item.MainWindowTitle != "" && item.MainModule.ModuleName != "taskmgr.exe"
                        //&& item.MainModule.ModuleName != "VCSExpress.exe" 
                        && item.MainModule.ModuleName != "explorer.exe"
                        )
                    {
                        // プロセスの Intptr を保存
                        myProcess[SetData.DATA.number].Add(item.MainWindowHandle);
                        // プロセスを隠す
                        SetWindowPos(item.MainWindowHandle, HWND_TOP, 0, 0, 0, 0, WSP_HIDE);
                    }
                }
                catch { }
                finally
                {
                    item.Close();
                }
            }
        }

        //---------------------------------------------------------------------
        /// <summary>
        /// デスクトップを移動したときプロセスを表示する
        /// </summary>
        private void Show_process()
        {
            // 保存されているプロセス分まわす
            foreach (IntPtr item in myProcess[SetData.DATA.number])
            {
                try
                {
                    // プロセスを表示
                    SetWindowPos(item, HWND_TOP, 0, 0, 0, 0, WSP_SHOW);
                }
                catch { }
            }
        }

        //---------------------------------------------------------------------
        /// <summary>
        /// 全てのプロセスを表示する
        /// </summary>
        private void ShowAll_process()
        {
            // リストの大きさ分まわす
            for (int i = 0; i < myProcess.Count(); i++)
            {
                // リストの中身分まわす
                foreach (IntPtr item in myProcess[i])
                {
                    try
                    {
                        // プロセスの表示
                        SetWindowPos(item, HWND_TOP, 0, 0, 0, 0, WSP_SHOW);
                    }
                    catch { }
                }
            }
        }

        /*****************************************************************************************
         *****************************************************************************************
         *****************************************************************************************
         *****                                                                               *****
         *****                                  APIのclass                                   *****
         *****                                                                               *****
         *****************************************************************************************
         *****************************************************************************************
         *****************************************************************************************/

        //---------------------------------------------------------------------
        /// <summary>
        /// HookかけるAPIのclass
        /// </summary>
        private class WinHookAPI
        {
            // フックプロシージャのためのデリゲート
            public delegate IntPtr HookProcedureDelegate(int nCode, IntPtr wParam, IntPtr lParam);

            // フックプロシージャ"lpfn"をフックチェーン内にインストールする
            // 返り値はフックプロシージャのハンドル
            [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
            public static extern IntPtr SetWindowsHookEx(int idHook, HookProcedureDelegate lpfn, IntPtr hInstance, int threadId);

            // "SetWindowHookEx"でインポートされたフックプロシージャを削除する
            [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
            public static extern bool UnhookWindowsHookEx(IntPtr idHook);

            // 次のフックプロシージャにフック情報を渡す
            [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
            public static extern IntPtr CallNextHookEx(IntPtr idHook, int nCode, IntPtr wParam, IntPtr lParam);

            // GetModuleHandleメソッドをインポート
            [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
            public static extern IntPtr GetModuleHandle(String lpModuleName);
        }

        //---------------------------------------------------------------------
        /// <summary>
        /// マウスフック関連のclass
        /// </summary>
        private class MouseHookInfo
        {
            // フックプロシージャのハンドルを保存しておくための、静的フィールドを用意
            public static IntPtr hHook = IntPtr.Zero;

            // マウスに対するフックタイプを宣言
            public const int WH_MOUSE_LL = 14;

            // マウスの位置用の構造体
            [StructLayout(LayoutKind.Sequential)]
            public struct POINT
            {
                public int x;
                public int y;
            }

            // マウスフックをあらわす構造体
            [StructLayout(LayoutKind.Sequential)]
            public class MouseHookStruct
            {
                public POINT pt;
                public uint mouseData;
                public uint flags;
                public uint time;
                public IntPtr dwExtraInfo;
            }

            // 定数を定義
            public const int WM_LBUTTONDOWN = 0x201;
            public const int WM_LBUTTONUP = 0x202;
            public const int WM_RBUTTONDOWN = 0x204;
            public const int WM_RBUTTONUP = 0x205;
            public const int WM_MBUTTONDOWN = 0x207;
            public const int WM_MBUTTONUP = 0x208;
            public const int WM_MBUTTONDBLCLK = 0x209;
            public const int WM_MOUSEMOVE = 0x200;
            public const int WM_MOUSEWHEEL = 0x20A;
        }

        //---------------------------------------------------------------------
        /// <summary>
        /// キーボード関連のclass
        /// </summary>
        private class KeyboardHookInfo
        {
            // フックプロシージャのハンドルを保存しておくための、静的フィールドを用意
            public static IntPtr hHook = IntPtr.Zero;

            // キーボードに対するフックタイプを宣言
            public const int WM_KEYBOARD_LL = 13;

            // キーを表す構造体
            [StructLayout(LayoutKind.Sequential)]
            public struct KeyboardHookStruct
            {
                public Int32 VKCode;
                public Int32 ScanCode;
                public Int32 Flags;
                public Int32 Time;
                public Int32 ExtraInfo;
            }

            // 定数を定義     
            public const int WM_KEYDOWN = 0x100;
            public const int WM_KEYUP = 0x101;
            public const int WM_SYSKEYDOWN = 0x104;
            public const int WM_SYSKEYUP = 0x105;
            public const int VK_RIGHT = 0x27;          //→が押されたとき
            public const int VK_LEFT = 0x25;           //←が押されたとき
            public const int VK_LCONTROL = 0xA2;       //右のctrlが押されたとき
            public const int VK_RCONTROL = 0xA3;       //左のcrtlが押されたとき
            public const int VK_CONTROL = 0x11;        //CTRLが押されたとき
        }

        //---------------------------------------------------------------------
        /// <summary>
        /// デスクトップのアイコンの場所関連のclass
        /// </summary>
        private class WinProcessAPI
        {
            // delegate の定義
            private delegate int EnumWindowsDelegate(IntPtr hWnd, int lParam);
            // ウィンドウを列挙する
            [DllImport("user32.dll")]
            private static extern int EnumWindows(EnumWindowsDelegate lpEnumFunc, int lParam);
            // ウィンドウが見えているかどうか
            [DllImport("user32.dll")]
            private static extern int IsWindowVisible(IntPtr hWnd);
            // ウィンドウにキャプションがあるかどうか
            [DllImport("user32.dll", CharSet = CharSet.Auto)]
            private static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);
            // ウィンドウのプロセスを取得
            [DllImport("user32.dll")]
            private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out int lpdwProcessId);
            // ハンドルの名前を取得する
            [DllImport("user32.dll")]
            private static extern int GetClassName(IntPtr hWnd, StringBuilder lpClassName, int nMaxCount); 
            // 指定した名前を持つウィンドウハンドルを取得する
            [DllImport("user32.dll")]
            private static extern IntPtr FindWindow(string strclassName, string strWindowName);
            // 指定した親の子で、指定した名前のウィンドウハンドルを取得する
            [DllImport("user32", EntryPoint = "FindWindowEx")]
            private static extern IntPtr FindWindowEx(IntPtr hWnd1, IntPtr hWnd2, string lpsz1, string lpsz2);
            // プロセス間のデータのやり取りをする
            [DllImport("user32.dll")]
            private static extern int SendMessage(IntPtr hWnd, int wMsg, int wParam, IntPtr lParam);
            // 指定したプロセスIDを取得する
            [DllImport("user32.dll")]
            private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);
            // していたプロセスを開く
            [DllImport("kernel32.dll")]
            private static extern IntPtr OpenProcess(uint dwDesiredAccess, bool bInheritHandle, uint dwProcessId);
            // メモリ領域を確保する
            [DllImport("kernel32.dll")]
            private static extern IntPtr VirtualAllocEx(IntPtr hProcess, IntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);
            // メモリにデータを書き込む
            [DllImport("kernel32")]
            private static extern bool WriteProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, ref LV_ITEM buffer, int dwSize, IntPtr lpNumberOfBytesWritten);
            // メモリからデータを読み取る
            [DllImport("kernel32.dll")]
            private static extern bool ReadProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, IntPtr lpBuffer, int nSize, IntPtr vNumberOfBytesRead);
            // メモリ領域を解放する
            [DllImport("kernel32.dll")]
            private static extern bool VirtualFreeEx(IntPtr hProcess, IntPtr lpAddress, uint dwSize, uint dwFreeType);
            // ハンドルを解放する
            [DllImport("kernel32.dll")]
            private static extern bool CloseHandle(IntPtr hObject);

            // 以下定数
            public const int MAX_BUF = 1024;
            public const uint PROCESS_VM_OPERATION = 0x8;
            public const uint PROCESS_VM_READ = 0x10;
            public const uint PROCESS_VM_WRITE = 0x20;
            public const uint MEM_RESERVE = 0x2000;
            public const uint MEM_COMMIT = 0x1000;
            public const uint PAGE_READWRITE = 0x4;
            public const int LVM_GETITEMPOSITION = 0x1010;
            public const int LVM_GETITEMCOUNT = 0x1004;
            public const int LVM_SETITEMPOSITION = 0x100F;
            public const int LVM_GETEXTENDEDLISTVIEWSTYLE = 0x1037;
            public const int LVM_SETEXTENDEDLISTVIEWSTYLE = 0x1036;
            public const int LVS_EX_SNAPTOGRID = 0x80000;
            public const int LVM_GETITEM = 0x1005;
            public const int LVIF_TEXT = 0x0001;
            public const uint MEM_RELEASE = 0x8000;

            // findindexで使う変数
            public static string checkstr = "";

            // リストビュー構造体
            [StructLayout(LayoutKind.Sequential)]
            public struct LV_ITEM
            {
                public uint mask;
                public int iItem;
                public int iSubItem;
                public uint state;
                public uint stateMask;
                public IntPtr pszText;
                public int cchTextMax;
                public int iImage;
            }

            /// <summary>
            /// 起動中のウィンドウを全て取得する
            /// </summary>
            /// <returns>取得したウィンドウのプロセスのリストを返す</returns>
            public static List<Process> GetAllWindows()
            {
                // リスト作成
                List<Process> wind = new List<Process>();

                // api でウィンドウを取得
                EnumWindows(new EnumWindowsDelegate(delegate(IntPtr hWnd, int lParam)
                {
                    StringBuilder sb = new StringBuilder(0x1024);
                    // ウィンドウが表示されてて，ウィンドウにキャプションがあるとき
                    if (IsWindowVisible(hWnd) != 0 && GetWindowText(hWnd, sb, sb.Capacity) != 0)
                    {
                        int pid;
                        // 取得して，リストにつむ
                        GetWindowThreadProcessId(hWnd, out pid);
                        Process p = Process.GetProcessById(pid);
                        wind.Add(p);
                    }
                    return 1;
                }), 0);

                return wind;
            }

            /// <summary>
            /// デスクトップのハンドルを格納する
            /// </summary>
            /// <returns>取得したハンドル</returns>
            private static IntPtr GetDesktopHandle()
            {
                IntPtr hWnd = IntPtr.Zero;

                // デスクトップのハンドル取得
                hWnd = FindWindow("Progman", "Program Manager");
                hWnd = FindWindowEx(hWnd, IntPtr.Zero, "SHELLDLL_DefView", null);
                hWnd = FindWindowEx(hWnd, IntPtr.Zero, "SysListView32", null);

                // もし取得できなかったら
                if (hWnd == IntPtr.Zero)
                {
                    // WorkerW にあるかもしれないのですべてのウィンドウから
                    // SHELLDLL_DefView を子に持つ WorkerW を探す
                    EnumWindows(new EnumWindowsDelegate(delegate(IntPtr hWnd2, int lParam)
                    {
                        StringBuilder sb = new StringBuilder();
                        // ハンドルの名前を取得する
                        GetClassName(hWnd2, sb, sb.Capacity);

                        if (sb.ToString() == "WorkerW")
                        {
                            // SHELLDLL_DefView を取得してみる
                            hWnd2 = FindWindowEx(hWnd2, IntPtr.Zero, "SHELLDLL_DefView", null);

                            // 取得できなかったら
                            if (hWnd2 != IntPtr.Zero)
                            {
                                // SysListView32 を取得してみる
                                hWnd2 = FindWindowEx(hWnd2, IntPtr.Zero, "SysListView32", "FolderView");
                                if (hWnd2 != IntPtr.Zero)
                                {
                                    // 保存して return
                                    hWnd = hWnd2;
                                    return 1;
                                }
                            }
                        }

                        return 1;

                    }), 0);
                }

                return hWnd;
            }
            
            /// <summary>
            /// デスクトップのアイコンの場所を取得する
            /// </summary>
            /// <returns>取得したアイコン座標のリスト</returns>
            public static List<System.Drawing.Point> GetIconPosition()
            {
                // デスクトップのウィンドウハンドルを取得する
                IntPtr hWnd = GetDesktopHandle();
                IntPtr hProcess;
                IntPtr pnt;
                System.Drawing.Point[] iconPoint = new System.Drawing.Point[1];
                int iconCount;
                uint dwProcessId;

                // デスクトップアイコンの座標を格納するリストの初期化
                List<System.Drawing.Point> poslis = new List<System.Drawing.Point>();

                //アイコンの数を取得
                iconCount = SendMessage(hWnd, LVM_GETITEMCOUNT, 0, IntPtr.Zero);

                // ウィンドウのプロセスの取得
                GetWindowThreadProcessId(hWnd, out dwProcessId);
                // メモリ共有用のプロセスハンドル取得
                hProcess = OpenProcess(PROCESS_VM_OPERATION | PROCESS_VM_READ | PROCESS_VM_WRITE, false, dwProcessId);
                // 共有メモリを割り付け
                pnt = VirtualAllocEx(hProcess, IntPtr.Zero, MAX_BUF, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);

                for (int i = 0; i < iconCount; i++)
                {
                    //アイコンの位置を取得
                    SendMessage(hWnd, LVM_GETITEMPOSITION, i, pnt);
                    // メモリから位置を取得する
                    ReadProcessMemory(hProcess, pnt, Marshal.UnsafeAddrOfPinnedArrayElement(iconPoint, 0), Marshal.SizeOf(typeof(System.Drawing.Point)), IntPtr.Zero);
                    // 座標をリストに保存
                    poslis.Add(iconPoint[0]);
                }

                // デスクトップ側のプロセスにメモリを解放
                VirtualFreeEx(hProcess, pnt, 0, MEM_RELEASE);
                // デスクトップのプロセスハンドル解放
                CloseHandle(hProcess);

                return poslis;
            }

            /// <summary>
            /// 指定した座標にデスクトップのアイコンを並び替える
            /// </summary>
            /// <param name="poslis">アイコン座標のリスト</param>
            public static void SetIconPosition(List<System.Drawing.Point> poslis, List<string> namelis)
            {
                // デスクトップのウィンドウハンドルを取得する
                IntPtr hWnd = GetDesktopHandle();
                int iconCount;
                bool set_flg = false;

                //アイコンの数を取得
                iconCount = SendMessage(hWnd, LVM_GETITEMCOUNT, 0, IntPtr.Zero);

                // 現在の設定を取得
                int dwExStyle = (int)SendMessage(hWnd, LVM_GETEXTENDEDLISTVIEWSTYLE, 0, IntPtr.Zero);

                // 等間隔に整列 がついてたら
                if ((dwExStyle & LVS_EX_SNAPTOGRID) != 0)
                {
                    // フラグを立てる
                    set_flg = true;
                    // 等間隔に整列 をはずす
                    SendMessage(hWnd, LVM_SETEXTENDEDLISTVIEWSTYLE, 0, IntPtr.Zero);
                }

                //デスクトップのアイコンを画面外にいどうさせる
                for (int i = 0; i < iconCount && i < poslis.Count(); i++)
                {
                    IntPtr point = new IntPtr(((2000 + i * 100) << 16) | ((2000 + i * 100) & 0xFFFF));
                    // アイコンを並べなおす
                    SendMessage(hWnd, LVM_SETITEMPOSITION, i, point);
                }

                List<string> deskname = GetIconName();
                //デスクトップのアイコンを元に戻す
                for (int i = 0; i < iconCount && i < poslis.Count(); i++)
                {
                    // 同じ名前のアイコンを移動させる
                    checkstr = deskname[i];
                    int j = namelis.FindIndex(CheckName);

                    IntPtr point = new IntPtr((poslis[j].Y << 16) | (poslis[j].X & 0xFFFF));
                    // アイコンを並べなおす
                    SendMessage(hWnd, LVM_SETITEMPOSITION, i, point);
                }

                // 等間隔に整列をつける
                if (set_flg) SendMessage(hWnd, LVM_SETEXTENDEDLISTVIEWSTYLE, 0, (IntPtr)LVS_EX_SNAPTOGRID);
            }

            /// <summary>
            /// デスクトップのアイコンの名前を取得する
            /// </summary>
            /// <returns>取得した名前のリスト</returns>
            public static List<string> GetIconName()
            {
                uint dwProcessId;
                LV_ITEM lvItem = new LV_ITEM();
                IntPtr hProcess = IntPtr.Zero;
                IntPtr lviBuffer = IntPtr.Zero;
                IntPtr strBuffer = IntPtr.Zero;
                IntPtr threadId = IntPtr.Zero;
                List<string> iconname = new List<string>();

                // デスクトップのウィンドウハンドルを取得する
                IntPtr hWnd = GetDesktopHandle();
                int iconCount;

                //アイコンの数を取得
                iconCount = SendMessage(hWnd, LVM_GETITEMCOUNT, 0, IntPtr.Zero);

                // 結果を保存するメモリの確保
                strBuffer = Marshal.AllocHGlobal(MAX_BUF);

                // ウィンドウのプロセスの取得
                GetWindowThreadProcessId(hWnd, out dwProcessId);

                // メモリ共有用のプロセスハンドル取得
                hProcess = OpenProcess(PROCESS_VM_OPERATION | PROCESS_VM_READ | PROCESS_VM_WRITE, false, dwProcessId);

                // 共有メモリを割り付け
                lviBuffer = VirtualAllocEx(hProcess, IntPtr.Zero, MAX_BUF, MEM_COMMIT, PAGE_READWRITE);

                // リストビュー構造体の設定
                lvItem.mask = LVIF_TEXT;
                lvItem.iItem = 0;
                lvItem.pszText = (IntPtr)(lviBuffer.ToInt32() + Marshal.SizeOf(typeof(LV_ITEM)));
                lvItem.cchTextMax = 50;

                for (int i = 0; i < iconCount; i++)
                {
                    // 何番目かを設定する
                    lvItem.iItem = i;

                    // リストビュー構造体を共有メモリに書き込む
                    WriteProcessMemory(hProcess, lviBuffer, ref lvItem, Marshal.SizeOf(typeof(LV_ITEM)), IntPtr.Zero);

                    // 共有メモリをからリストビューの名前を取得し,共有メモリに書き込む
                    SendMessage(hWnd, LVM_GETITEM, 0, lviBuffer);

                    // 共有メモリをから sendmessage の結果を読み取る
                    ReadProcessMemory(hProcess, lviBuffer, strBuffer, MAX_BUF, IntPtr.Zero);

                    // 読み取った文字をstring に変換
                    string str = Marshal.PtrToStringAnsi((IntPtr)(strBuffer.ToInt32() + Marshal.SizeOf(typeof(LV_ITEM))));

                    // 名前をリストに保存する
                    iconname.Add(str);
                }

                return iconname;
            }

            /// <summary>
            /// FindIndexで使う
            /// </summary>
            /// <param name="name"></param>
            /// <returns></returns>
            private static bool CheckName(string name)
            {
                return checkstr == name;
            }
        }

        //---------------------------------------------------------------------

    }
}
