﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Xml.Serialization;
using System.Windows.Media;
using System.IO;
using Microsoft.Win32;

namespace Desktop_pp
{
    // xmlファイルにするときに使っている型を有効にする
    [XmlInclude(typeof(System.Windows.Media.MatrixTransform))]
    [XmlInclude(typeof(System.Windows.Interop.InteropBitmap))]
    public class SetData
    {
        // cドライブの直下に desktop のフォルダを作るパス
        public static string setpath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Desktop++;");
        // デスクトップの最大数
        public const int DESK_MAX = 12;

        // フォルダ名を保存する
        private List<string> _name;
        public List<string> name
        {
            get
            {
                if (_name == null)
                    _name = new List<string>();
                return _name;
            }
            set
            {
                _name = value;
            }
        }
        // 壁紙のパスを保存する
        private List<string> _image;
        public List<string> image
        {
            get
            {
                if (_image == null)
                    _image = new List<string>();
                return _image;
            }
            set
            {
                _image = value;
            }
        }
        // サイドバーの背景色を保存する
        private SolidColorBrush _mcolor;
        public SolidColorBrush mcolor
        {
            get
            {
                if (_mcolor == null)
                    _mcolor = new SolidColorBrush();
                return _mcolor;
            }
            set
            {
                _mcolor = value;
            }
        }
        // 表示ウィンドウの背景色を保存する
        private SolidColorBrush _pcolor;
        public SolidColorBrush pcolor
        {
            get
            {
                if (_pcolor == null)
                    _pcolor = new SolidColorBrush();
                return _pcolor;
            }
            set
            {
                _pcolor = value;
            }
        }
        // スクリーンショットを格納する
        private List<ImageSource> _scrimg;
        public List<ImageSource> scrimg
        {
            get
            {
                if (_scrimg == null)
                    _scrimg = new List<ImageSource>();
                return _scrimg;
            }
            set
            {
                _scrimg = value;
            }
        }
        // サイドバーの大きさを保存する
        public double sideh { get; set; }
        // サイドバーのセンタリング(位置)を保存する
        public double sidec { get; set; }
        // サイドバーの透明度を保存する
        public double sideo { get; set; }
        // 表示状態を保存
        public bool topmost { get; set; }
        // アニメーションの有無切り替え
        public bool aniflg { get; set; }
        // ワークスペースの有無切り替え
        public bool workflg { get; set; }
        // サイドバーの透明度を保存する
        public double prio { get; set; }
        // サイドバーを表示するかしないのか
        public bool privisi { get; set; }
        // 初期のデスクトップのレジストリ値を保存しておく
        public string defdesk { get; set; }
        // 初期のデスクトップの背景画像のレジストリ値を保存しておく
        public string defimg { get; set; }
        // 現在のデスクトップの番号を保存しておく
        public int number { get; set; }
        // colordialogのカスタム色を保存する
        public int[] setcolor { get; set; }

        // デスクトップのアイコンの場所を保存する
        private List<List<System.Drawing.Point>> _ipoint = new List<List<System.Drawing.Point>>();
        public List<List<System.Drawing.Point>> ipoint
        {
            get 
            {
                if (_ipoint == null)
                    _ipoint = new List<List<System.Drawing.Point>>();
                return _ipoint;
            }
            set
            {
                _ipoint = value;
            }
        }
        // デスクトップのアイコンの名前保存する
        private List<List<string>> _iname = new List<List<string>>();
        public List<List<string>> iname
        {
            get
            {
                if (_iname == null)
                    _iname = new List<List<string>>();
                return _iname;
            }
            set
            {
                _iname = value;
            }
        }

        // このclassの自己参照インスタンス
        private static SetData _DATA;
        public static SetData DATA
        {
            get
            {
                if (_DATA == null)
                {
                    _DATA = new SetData();
                    _DATA.set();
                }
                return _DATA;
            }
            set
            {
                _DATA = value;
            }
        }

        //---------------------------------------------------------------------
        /// <summary>
        /// 初期化の関数
        /// </summary>
        public void set()
        {
            // パスの指定
            string wallkey;
            string deskpath = @"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders";
            string wallpath = @"HKEY_CURRENT_USER\Software\Microsoft\Internet Explorer\Desktop\General";

            // osのversion取得
            Version OSver = Environment.OSVersion.Version;
            // windows7だったら
            if ((OSver.Major == 6 && OSver.Minor >= 1) || OSver.Major > 6)
            {
                wallkey = "WallpaperSource";
            }
            // それ以外だったら
            else
            {
                wallkey = "Wallpaper";
            }
            
            // 以下初期設定
            defdesk = Registry.GetValue(deskpath, "Desktop", "default") as string; ;
            defimg = Registry.GetValue(wallpath, wallkey, "default") as string;
            name.Add("初期デスクトップ");
            image.Add(defimg);
            scrimg.Add(null);
            sidec = 0.0;
            sideo = 50;
            sideh = 0.0;
            prio = 100;
            mcolor.Color = Colors.Yellow;
            pcolor.Color = Colors.Yellow;
            topmost = true;
            aniflg = true;
            workflg = true;
            privisi = true;
            ipoint.Add(new List<System.Drawing.Point>());
            iname.Add(new List<string>());
            System.IO.Directory.CreateDirectory(setpath);
        }

        //---------------------------------------------------------------------
        /// <summary>
        /// 設定を XML ファイルから読み込み復元する
        /// </summary>
        public static void LoadXmlFile()
        {
            try
            {
                // パスを開く
                using (FileStream fs = new FileStream(setpath + "\\Desktop++;.config", FileMode.Open, FileAccess.Read))
                {
                    // xmlファイル開く
                    System.Xml.Serialization.XmlSerializer xml = new System.Xml.Serialization.XmlSerializer(typeof(SetData));
                    // 読み込んで逆シリアル化する
                    object obj = xml.Deserialize(fs);
                    // 閉じる
                    fs.Close();
                    // キャストして代入
                    DATA = (SetData)obj;
                }
            }
            catch
            {
            }
        }

        //---------------------------------------------------------------------
        /// <summary>
        /// 現在の設定を XML ファイルに保存する
        /// </summary>
        public static void SaveXmlFile()
        {
            // スクリーンショットのimageを初期化
            for (int i = 0; i < DATA.scrimg.Count(); i++)
            {
                DATA.scrimg[i] = null;
            }
            // パスを開く
            using (FileStream fs = new FileStream(setpath + "\\Desktop++;.config", FileMode.Create, FileAccess.Write))
            {
                // xmlファイル開く
                System.Xml.Serialization.XmlSerializer xml = new System.Xml.Serialization.XmlSerializer(typeof(SetData));
                //シリアル化して書き込む
                xml.Serialize(fs, DATA);
                // 閉じる　
                fs.Close();
            }
        }
    }
}
