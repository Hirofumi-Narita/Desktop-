﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Desktop_pp
{
    /// <summary>
    /// AddWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class AddWindow : Window ,IDisposable
    {
        // コンストラクタ
        public AddWindow()
        {
            InitializeComponent();
            // ボタンが押されたらときのイベント
            // 閉じるようにする
            cancelbutton.Click += (sender, e) => this.Close();
        }

        // デストラクタ
        public void Dispose()
        {
            // 閉じる
            this.Close();
        }
    }
}