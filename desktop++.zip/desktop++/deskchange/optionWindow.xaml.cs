﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Desktop_pp
{
    /// <summary>
    /// 設定のウィンドウ
    /// </summary>
    public partial class optionWindow : Window
    {
        //-------------------- コンストラクタ -----------------------
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public optionWindow()
        {
            InitializeComponent();

            // チェックボタンをクリックしたときのイベントを追加
            anicheck.Click += (sender, e) => SetData.DATA.aniflg = (bool)anicheck.IsChecked;
            workcheck.Click += (sender, e) => SetData.DATA.workflg = (bool)workcheck.IsChecked;
            pvcheck.Click += (sender, e) => SetData.DATA.privisi = (bool)pvcheck.IsChecked;
        }

        /// <summary>
        /// ウィンドウの初期設定
        /// </summary>
        public void set()
        {
            //foldlist.Items.Clear();
            // リストボックスに現在のあるフォルダ名を全部代入する
            for (int i = 0; i < SetData.DATA.name.Count(); i++)
            {
                foldlist.Items.Add(SetData.DATA.name[i]);
            }
            // 背景色を変更
            mcolorabel.Background = SetData.DATA.mcolor;
            pcolorabel.Background = SetData.DATA.pcolor;

            // sliderの値を保存されている値にする
            opacbar.Value = SetData.DATA.sideo;
            sizebar.Value = SetData.DATA.sideh;
            centbar.Value = SetData.DATA.sidec;
            opacpri.Value = SetData.DATA.prio;

            // チェックボタンの状態を変更する
            topcheck.IsChecked = SetData.DATA.topmost;
            anicheck.IsChecked = SetData.DATA.aniflg;
            workcheck.IsChecked = SetData.DATA.workflg;
            pvcheck.IsChecked = SetData.DATA.privisi;
        }

        //-------------------- リストボックス -----------------------

        /// <summary>
        /// 選択されている項目が変更されたら
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void listBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // 何も選択されていないとき
            if (foldlist.SelectedIndex == -1) return;

            // 初期デスクトップは名前を変更できなくする
            if (foldlist.SelectedIndex == 0) namebutton.IsEnabled = false;
            else namebutton.IsEnabled = true;

            // 有効にする
            deletebutton.IsEnabled = true;

            // テキストボックスに選択したフォルダの名前を代入する
            nametext.Text = SetData.DATA.name[foldlist.SelectedIndex];
            try
            {
                // テキストボックスに選択した壁紙のパスを代入
                image1.Source = new BitmapImage(new Uri(SetData.DATA.image[foldlist.SelectedIndex]));
                image1.Stretch = Stretch.Uniform;
            }
            catch 
            {
                image1.Source = null;
            }
        }

        //-------------------- 詳細設定 -----------------------

        /// <summary>
        /// フォルダを追加するためのウィンドウを作成する
        /// また，そのウィンドウのコントロールのイベントなどの作成
        /// </summary>
        private void addbutton_Click(object sender, RoutedEventArgs e)
        {
            // デスクトップが12こ以上作られていたら
            if (SetData.DATA.name.Count() > SetData.DESK_MAX)
            {
                MessageBox.Show("これ以上デスクトップは作れません。", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // 新規インスタンス作成
            using (AddWindow adwindow = new AddWindow())
            {
                // 「追加」ボタンを押したときのイベント
                adwindow.addbutton.Click += (a, b) =>
                {
                    // 入力されている名前を格納
                    string newname = adwindow.nametext.Text;

                    //ファイル名に使用できない文字を取得
                    char[] invalidChars = System.IO.Path.GetInvalidPathChars();

                    if (newname == "" || newname.IndexOfAny(invalidChars) >= 0 || newname.IndexOf(" ") >= 0 || newname.IndexOf("　") >= 0)
                    {
                        MessageBox.Show("使用できない文字が含まれています。", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

                    // すでに作られていないかどうかチェック
                    for (int i = 0; i < SetData.DATA.name.Count(); i++)
                    {
                        // 同じ名前のデスクトップがあったら
                        if (SetData.DATA.name[i] == newname)
                        {
                            MessageBox.Show("同じ名前のデスクトップは作れません。", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
                            return;
                        }
                    }

                    // フォルダ追加
                    SetData.DATA.name.Add(newname);
                    SetData.DATA.image.Add(SetData.DATA.defimg);
                    SetData.DATA.scrimg.Add(null);
                    // フォルダを作成
                    System.IO.Directory.CreateDirectory(@"C:\Desktop++;\" + newname);
                    // リストに追加
                    foldlist.Items.Add(newname);

                    // 追加のウィンドウを消す
                    adwindow.Close();
                };

                // ウィンドウ表示
                adwindow.ShowDialog();
            }
        }

        //-------------------- その他 -----------------------

        //---------------------------------------------------------------------
        /// <summary>
        /// ボタンが押されたら，デスクトップの名前を変更する
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void namebutton_Click(object sender, RoutedEventArgs e)
        {
            // 何も選択されていないとき
            if (foldlist.SelectedIndex < 1) return;

            // 入力されている名前を格納
            string newname = nametext.Text;

            //ファイル名に使用できない文字を取得
            char[] invalidChars = System.IO.Path.GetInvalidPathChars();

            if (newname == "" || newname.IndexOfAny(invalidChars) >= 0 || newname.IndexOf(" ") >= 0 || newname.IndexOf("　") >= 0)
            {
                MessageBox.Show("使用できない文字が含まれています。", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // 全部のデスクトップを見る
            for (int i = 0; i < SetData.DATA.name.Count(); i++)
            {
                // 同じ名前のデスクトップがあったらエラー
                if (SetData.DATA.name[i] == newname)
                {
                    MessageBox.Show("同じ名前のデスクトップは作れません。", "エラー", MessageBoxButton.OK ,MessageBoxImage.Error);
                    return;
                }
            }
            try
            {
                // フォルダの名前を変更
                System.IO.Directory.Move(@"C:\Desktop++;\" + SetData.DATA.name[foldlist.SelectedIndex].ToString(), @"C:\Desktop++;\" + newname);
            }
            catch { }
                
            // 新しい名前に変更
            SetData.DATA.name[foldlist.SelectedIndex] = newname;
            // リストボックスの中身変更
            foldlist.Items[foldlist.SelectedIndex] = newname;
            foldlist.SelectedValue = newname;
        }

        //---------------------------------------------------------------------
        // スライダーの値が変更されたらそれにあわせて表示する値を変更する
        private void centbar_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            centlabel.Content = string.Format("( {0} %)", (int)centbar.Value);
        }

        private void sizebar_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            sizelabel.Content = string.Format("( {0} %)", (int)sizebar.Value);
        }

        private void opacbar_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            oplabel.Content = string.Format("( {0} %)", (int)opacbar.Value);
        }

        private void opacpri_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            popalabel.Content = string.Format("( {0} %)", (int)opacpri.Value);
        }

        //---------------------------------------------------------------------
        /// <summary>
        /// ウィンドウが閉じられるとき
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OpWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // 非表示にする
            this.Hide();
            // 変更を保存する
            closebutton_Click(null, null);
            
            // closeをさせない
            e.Cancel = true;
        }
        
        /// <summary>
        /// 閉じるを押した時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void closebutton_Click(object sender, RoutedEventArgs e)
        {
            // 非表示にする
            this.Hide();
            // それぞれのvalueの値を保存する
            SetData.DATA.sideh = sizebar.Value;
            SetData.DATA.sidec = centbar.Value;
            SetData.DATA.sideo = opacbar.Value;
            SetData.DATA.prio = opacpri.Value;
            
            SetData.DATA.topmost = (bool)topcheck.IsChecked;

            // 色を保存する
            SetData.DATA.mcolor = (SolidColorBrush)mcolorabel.Background;
            SetData.DATA.pcolor = (SolidColorBrush)pcolorabel.Background;
        }
    }
}